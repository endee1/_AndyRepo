import time
import os
import xbmc
import xbmcgui
import xbmcaddon

def deleteDB():
    try:
        xbmc.log("[Andy.plugin.program.Guide] Deleting Guide listing Choices...", xbmc.LOGDEBUG)
        dbPath = xbmc.translatePath(xbmcaddon.Addon(id = 'Andy.plugin.program.Guide').getAddonInfo('profile'))
        dbPath = os.path.join(dbPath, 'guide.ini')
        delete_file(dbPath)
        passed = not os.path.exists(dbPath)
        if passed:
            xbmc.log("[Andy.plugin.program.Guide] Deleting Guide listing Choices...PASSED", xbmc.LOGDEBUG)
        else:
            xbmc.log("[Andy.plugin.program.Guide] Deleting Guide listing Choices...FAILED", xbmc.LOGDEBUG)
        return passed

    except Exception, e:
        xbmc.log('[Andy.plugin.program.Guide] Deleting Guide listing Choices...EXCEPTION', xbmc.LOGDEBUG)
        return False

def delete_file(filename):
    tries = 10
    while os.path.exists(filename) and tries > 0:
        try:
            os.remove(filename)
            break
        except:
            tries -= 1

if __name__ == '__main__':
    if deleteDB():
        d = xbmcgui.Dialog()
        d.ok('TV Guide', 'Deleting Guide listing Choices has been successfully deleted.', 'It will be re-created next time you start the guide')
    else:
        d = xbmcgui.Dialog()
        d.ok('TV Guide', 'Failed to delete Guide listing Choices.', 'File may be locked,', 'please restart Kodi and try again')