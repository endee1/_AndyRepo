# -*- coding: utf-8 -*-



from __future__ import unicode_literals
from collections import namedtuple
import codecs
import sys,os,json,urllib2
import xbmc, xbmcgui, xbmcaddon, xbmcplugin,re
import shutil
import time
import datetime
import base64
import requests
import xbmcvfs
import urllib
import random
import hashlib
import pickle
import requests.packages.urllib3
requests.packages.urllib3.disable_warnings()

# for unicode utf asci
reload(sys)
sys.setdefaultencoding("utf-8")

addon         = 'Andy.plugin.program.Guide'
ADDONID       = addon
addon_name    = addon
addonPath     = xbmc.translatePath(os.path.join('special://home/addons', addon))
basePath      = xbmc.translatePath(os.path.join('special://profile', 'addon_data', addon))
tmp_File      = os.path.join(basePath, '_backup.ini')
icon          = xbmc.translatePath(os.path.join('special://home/addons', addon, 'icon.png'))
dbPath        = xbmc.translatePath(xbmcaddon.Addon(addon).getAddonInfo('profile'))
dialog        = xbmcgui.Dialog();dp = xbmcgui.DialogProgress()

inipath       = xbmc.translatePath(os.path.join(basePath, 'resources', 'ini'))
m3upath       = xbmc.translatePath(os.path.join(basePath, 'resources', 'm3u'))

iptvsubs      = 'plugin.video.iptvsubs'# this will overwrite the other one with json version.
dex           = 'plugin.video.dex'


externaliniURL = base64.b64decode(b'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL2hhbGlrdXMvX0FuZHlSZXBvL21hc3Rlci9fZXBnLw==') # blah blah _AndyRepo/master/_epg/  
#externaliniURL  = base64.b64decode(b''aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL1JlbmVnYWRlc1RWL3JlcG9zaXRvcnkucmVuZWdhZGVzdHYvbWFzdGVyL2FkZG9uczIuaW5p') # ren
#externaliniURL  = base64.b64decode(b'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL21hY2JsaXp6YXJkL2RuYXR2Z3VpZGUta29kaS9tYXN0ZXIvYWRkb25zLmluaQ==') # dna



################################################# 
# Notification #
#################################################
def notify(header,msg,icon_path):
    duration=2000
    #xbmc.executebuiltin("XBMC.Notification(%s,%s, %s, %s)" % (header, msg, duration, icon_path))
    xbmcgui.Dialog().notification(header, msg, icon=icon_path, time=duration, sound=False)
#
################################################# 
# Get Proper time in regards to device interpolation #
#################################################
def validTime(setting, maxAge):
    previousTime = getPreviousTime(setting)
    now          = datetime.datetime.today()
    delta        = now - previousTime
    nSeconds     = (delta.days * 86400) + delta.seconds
    return nSeconds <= maxAge
#
#################################################
# Set addon Setting
#################################################     
def SetSetting(param, value):
    value = str(value)
    if GetSetting(param) == value:
        return
    xbmcaddon.Addon(addon).setSetting(param, value)
#
#################################################
# This is a pop up box notification
#################################################
def DialogOK(line1, line2='', line3=''):
    d = xbmcgui.Dialog()
    d.ok('Subscriptions', line1, line2 , line3)     
#
#################################################
# LOG
#################################################
def log(text):
    try:
        output = '%s V%s : %s' % ("Log", 'Error?', str(text))
        if DEBUG:
            xbmc.log(output)
        else:
            xbmc.log(output, xbmc.LOGDEBUG)
    except: pass     
#
#################################################
# m3u8 to TS new file
#################################################
def M3U8_TS_New(Clean_Name,tmpFile):
    try:
        s=open(Clean_Name).read()
        s=s.replace('m3u8','ts')
        f=open(tmpFile,'w')
        f.write(s)
        f.close()
    except: pass        
# 
#################################################
# m3u8 to TS replace source file
#################################################
def M3U8_TS_Replace(Clean_Name,tmpFile):
    if os.path.exists(tmpFile):
        os.remove(tmpFile)
    os.rename(Clean_Name, tmpFile)
    s=open(tmpFile).read()
    #
    s=s.replace('m3u8','ts')
    #s=s.replace('.ts','.m3u8')
    #
    f=open(Clean_Name,'w')
    f.write(s)
    f.close()
    os.remove(tmpFile)   
#
#################################################
# Append source text to file
#################################################   
def AppendText(SourceFile, DestFile):
    try:
        s=open(SourceFile).read()
        f=open(DestFile,'a')
        f.write(s)
        f.close()
    except: pass
#
#################################################
# Replace Text in file
################################################# 
def ReplaceText(SourceFile, tmpFile, old1, new1, old2, new2, old3, new3, old4, new4):
    if os.path.exists(tmpFile):
        os.remove(tmpFile)
    os.rename(SourceFile, tmpFile)
    try:
        s=open(tmpFile).read()
        s=s.replace(old1, new1)
        s=s.replace(old2, new2)
        s=s.replace(old3, new3)
        s=s.replace(old4, new4)
        f=open(SourceFile,'a')
        f.write(s)
        f.close()
        os.remove(tmpFile)
    except: pass
#




###################################################################################################
################################################################################################### Subscriptions
###################################################################################################


#################################################
# IPTVsubs .ini and m3u                  Method 1
#################################################
def add_IPTVsubs():
    tempaddonPath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', iptvsubs))
    addonDirPath = xbmc.translatePath(os.path.join('special://home', 'addons', iptvsubs))
    addonDestFile = os.path.join(tempaddonPath, 'settings.xml')
    if os.path.exists(addonDirPath):    
        if os.path.exists(addonDestFile):
            try:  
                #notify('ini and m3u',iptvsubs,os.path.join('special://home/addons', iptvsubs, 'icon.png'))##NOTIFY##
                Name="iptvsubs";addon_name=iptvsubs;addon=xbmcaddon.Addon(addon_name)
                urlpath='http://2.welcm.tv:8000'
                username=addon.getSetting('kasutajanimi');password=addon.getSetting('salasona')
                groups = 'ENGLISH,SPORTS,FOR ADULTS'
                #write_style = 'w'
                Run_scraper(urlpath,addon_name,username,password,Name,groups)
            except: pass
#
# Not Needed - Replace Text Method
#################################################
# Get iptvsubs Pass and replace text in addon.ini #Not Needed
#################################################
def add_IPTVsubsTXT():
    addonSettingsFile = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.iptvsubs','settings.xml'))
    icon = xbmc.translatePath(os.path.join('special://home', 'addons', 'plugin.video.iptvsubs','icon.png'))
    if os.path.exists(addonSettingsFile):
        Source_File = os.path.join(basePath, 'addons.ini')
        #tmp_File = os.path.join(basePath, '_backup.ini')
        if os.path.exists(Source_File):
            #notify('ini',iptvsubs,os.path.join('special://home/addons', iptvsubs, 'icon.png'))##NOTIFY##
            addon=xbmcaddon.Addon('plugin.video.iptvsubs');user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona')         
            user_name_old='iptvsubsemail@gmail.com'       
            pass_word_old='iptvsubspass' 
            ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word, '','', '','')####ReplaceTXT

#

#################################################
# Add IPTVsubs beta .ini #               Method 1
#################################################
def add_IPTVsubsBeta():
    # Grab iptvsubs Beta Files    wip
    # 88888.se:8000/panel_api.php?username=thankyouall&password=kodibeta
    # urlpath+"/panel_api.php?username=thankyouall&password=kodibeta
    tempaddonPath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.ruyaiptv'))
    addonDirPath = xbmc.translatePath(os.path.join('special://home', 'addons', 'plugin.video.ruyaiptv'))
    addonDestFile = os.path.join(tempaddonPath, 'settings.xml')
    if os.path.exists(addonDirPath):    
        if os.path.exists(addonDestFile):
            try:    
                #notify('ini and m3u',iptvsubs,os.path.join('special://home/addons', iptvsubs, 'icon.png'))##NOTIFY##
                Name="IPTVSUBS Beta";addon_name='plugin.video.ruyaiptv';addon=xbmcaddon.Addon(addon_name)
                urlpath='http://bullsiptv.se:9850'
                #urlpath='http://88888.se:8000'
                #urlpath2 = addon.getSetting('server');urlpath=urlpath2   #  server  is   88888.se:8000
                username=addon.getSetting('username');password=addon.getSetting('password')
                groups = 'All channels'
                Run_scraper(urlpath,addon_name,username,password,Name,groups)
            except: pass
#
# Not Needed - Replace Text Method
#################################################
# Get iptvsubs beta Pass and replace text in addon.ini #Not Needed
#################################################
def add_IPTVsubsBetaTXT():
    addonSettingsFile = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.ruyaiptv','settings.xml'))
    icon = xbmc.translatePath(os.path.join('special://home', 'addons', 'plugin.video.ruyaiptv','icon.png'))
    if os.path.exists(addonSettingsFile):
        Source_File = os.path.join(basePath, 'addons.ini')
        #tmp_File = os.path.join(basePath, '_backup.ini')
        if os.path.exists(Source_File):
            #notify('ini','plugin.video.ruyaiptv',os.path.join('special://home/addons', 'plugin.video.ruyaiptv', 'icon.png'))##NOTIFY## 
            user_name_old='iptvsubsemail@gmail.com'       
            pass_word_old='iptvsubspass' 
            addon=xbmcaddon.Addon('plugin.video.ruyaiptv');user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona') 
            ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word, '','', '','')####ReplaceTXT    
#

#################################################
# Add Dex .ini #                         Method 1
#################################################
def add_Dex():
    tempaddonPath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', dex))
    addonDirPath = xbmc.translatePath(os.path.join('special://home', 'addons', dex))
    addonDestFile = os.path.join(tempaddonPath, 'settings.xml')
    if os.path.exists(addonDirPath):    
        if os.path.exists(addonDestFile):
            try:
                #notify('ini and m3u',dex,os.path.join('special://home/addons', dex, 'icon.png'))##NOTIFY##
                Name="dex";addon_name=dex;addon=xbmcaddon.Addon(addon_name)
                urlpath2 = addon.getSetting('lehekylg');urlpath=urlpath2+':8000'
                username=addon.getSetting('kasutajanimi');password=addon.getSetting('salasona')
                groups = '[COLOR oldlace][B]-- [COLOR deepskyblue]CANADA [COLOR oldlace]--[/B][/COLOR],[COLOR oldlace][B]-- [COLOR deepskyblue]USA [COLOR oldlace]--[/B][/COLOR],[COLOR oldlace][B]-- [COLOR deepskyblue]UK [COLOR oldlace]--[/B][/COLOR],[COLOR oldlace][B]-- [COLOR mediumpurple]KIDS [COLOR oldlace]--[/B][/COLOR],[COLOR oldlace][B]-- [COLOR mediumpurple]NEWS [COLOR oldlace]--[/B][/COLOR],[COLOR oldlace][B]-- [COLOR mediumpurple]SPORTS [COLOR oldlace]--[/B][/COLOR]'
                #write_style = 'a'
                Run_scraper(urlpath,addon_name,username,password,Name,groups)
            except: pass    
 #  
# Not Needed - Replace Text Method 
#################################################
# Get Dex Pass and replace text in addon.ini #Not Needed
#################################################
def add_DexTXT():
    addonSettingsFile = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'plugin.video.dex','settings.xml'))
    icon = xbmc.translatePath(os.path.join('special://home', 'addons', 'plugin.video.dex','icon.png'))
    if os.path.exists(addonSettingsFile):
        username=addon.getSetting('kasutajanimi');password=addon.getSetting('salasona')       
        Source_File = os.path.join(basePath, 'addons.ini')
        #tmp_File = os.path.join(basePath, '_backup.ini')
        if os.path.exists(Source_File):
            #notify('ini',dex,os.path.join('special://home/addons', dex, 'icon.png'))##NOTIFY##
            user_name_old='dexteremail@gmail.com'
            pass_word_old='dexterpass'      
            addon_name2='plugin.video.dex';addon=xbmcaddon.Addon(addon_name2);user_name=addon.getSetting('kasutajanimi');pass_word=addon.getSetting('salasona') 
            ReplaceText(Source_File, tmp_File, user_name_old, user_name, pass_word_old, pass_word, '','', '','')####ReplaceTXT
#



#################################################
# Create m3u and ini files #
#################################################
def Run_scraper(urlpath,addon_name,username,password,Name,groups):
    panel_url = urlpath+"/panel_api.php?username={}&password={}".format(username, password)  
    u = urllib2.urlopen(panel_url)
    j = json.loads(u.read())
    #
    # Channel ID Map
    my_map = {}    
    '''
    my_map = {"TREEHOUSE HD (NA)":"I80173.labs.zap2it.com",
              "FAMILY HD (NA)":"I70520.labs.zap2it.com",
              }
    '''          
    map_file =''
    if map_file:
      with open(map_file) as f:
        for line in f:
          sp_line = line.rstrip(os.linesep).split("\t")
          my_map[sp_line[0]] = sp_line[1]
    #
    # Renames channels as they are downloaded
    channelname_map = {"5*":"5Star", 
                       #"3E HD":"3e",
                       "5STAR MAX HD - NEW":"5StarMax",
                       "A+E HD":"A&E",
                       "5 Star":"5Star",
                       "ABC HD EAST":"ABC HD",                       
                       "ABC HD WEST - NEW":"ABC West",                      
                       "ABC NEWS":"ABC News",                       
                       "ACTION HD":"ACTION",
                       "ACTION MAX HD - NEW":"ActionMax",                       
                       "ALJAZEERA ENGLISH":"Aljazeera",                      
                       "AMAZING DISCOVERIES":"Amazing Discoveries",                       
                       "AMAZING FACTS":"Amazing Facts",    
                       "ANIMAL PLANET HD":"Animal Planet", 
                       "BBC AMERICA HD":"BBC America",
                       "BBC NEWS":"BBC News", 
                       "BBC One HD":"BBC1",
                       "BBC Two HD":"BBC2",
                       "BBC Three HD":"BBC3",
                       "BBC Four HD":"BBC4", 
                       "BC1 HD - NEW":"BC1", 
                       "BET HD":"BET",
                       "BLOOMBERG":"Bloomberg", 
                       "BNN HD - NEW":"BNN", 
                       "BOUNCE HD":"Bounce",
                       "BRAVO HD":"Bravo",
                       "CARTOON NETWORK HD (NA)":"Cartoon Network", 
                       "CBC EAST HD":"CBC", 
                       "CBC NEWS HD":"CBC News",
                       "CBC VANCOUVER HD- NEW":"CBC Vancouver", 
                       "CBS HD EAST":"CBS HD", 
                       "CBS HD WEST - NEW":"CBS West",
                       "CBS NEWS HD":"CBS News",
                       "CHCH HD":"CHCH",
                       "CINEMAX EAST HD - NEW":"Cinemax", 
                       "CITY TV HD":"City TV Toronto",
                       "CITY VANCOUVER HD - NEW":"City TV Vancouver", 
                       "CNBC HD":"CNBC", 
                       "CNN HD":"CNN",
                       #"COMEDY NETWORK HD":"Comedy Network",
                       "COMEDY NETWORK HD":"Comedy Central",
                       "CP24 HD":"CP24",
                       "CTV EAST HD":"CTV Toronto", 
                       "CTV NORTH":"CTV North",
                       "CTV VANCOUVER HD - NEW":"CTV Vancouver", 
                       "CW11 HD":"CW", 
                       "DISCOVERY HD":"Discovery",
                       "DISCOVERY SCIENCE HD":"Discovery Science",
                       "DISNEY HD EAST":"Disney",
                       "DISNEY XD HD (NA)":"Disney XD", 
                       "E! HD":"E!",
                       "ENCORE WESTERN HD - NEW":"Encore Western", 
                       "FAMILY HD (NA)":"FAMILY", 
                       "FOOD HD":"Food Network",
                       "FOX HD EAST":"FOX HD",
                       "FOX HD WEST - NEW":"FOX West",    
                       "FOX NEWS HD":"FOX News", 
                       "FX HD":"FX",
                       "FXX HD":"FXX", 
                       "GLOBAL BC HD - NEW":"Global Vancouver", 
                       "GLOBAL EAST HD":"Global Toronto",
                       "HALLMARK HD":"Hallmark",
                       "HBO COMEDY HD":"HBO Comedy", 
                       "HBO EAST HD":"HBO HD", 
                       "HBO SIGNATURE HD":"HBO Signature",
                       "HGTV HD":"HGTV", 
                       "HISTORY HD":"History", 
                       "HLN HD":"HLN",
                       "HSN 2":"HSN2",                       
                       "ID HD":"Discovery Investigation",
                       "IFC HD":"IFC",    
                       "LIFE HD":"Lifetime", 
                       "LIFETIME MOVIES HD":"LMN",
                       "MOREMAX HD - NEW":"MoreMax", 
                       "MOVIE TIME HD":"MovieTime", 
                       "MSNBC HD":"MSNBC",
                       "MTV HD":"MTV",
                       "NAT GEO HD":"National Geographic", 
                       "NAT GEO WILD HD":"Nat Geo Wild", 
                       "NBC HD EAST":"NBC HD",
                       "NBC HD WEST - NEW":"NBC West", 
                       "NICKELODEON HD (NA)":"Nickelodeon", 
                       "OMNI 1 HD":"OMNI 1",
                       "OMNI 2 HD":"OMNI 2",
                       "OWN HD":"OWN",    
                       "PBS HD":"PBS", 
                       "REV'N USA HD":"Rev USA",
                       "RT DOCUMENTARY HD":"RT Documentary", 
                       "RT NEWS HD":"RT News", 
                       "SHOWCASE HD":"SHOWCASE",
                       "SHOWTIME EAST":"Showtime HD",
                       "SHOWTIME SHOWCASE HD":"Showtime Showcase", 
                       "SKY CBBC HD":"CBBC", 
                       "SKY DISNEY JR (UK)":"Disney Jr UK",
                       "SKY DISNEY XD (UK)":"Disney XD UK", 
                       "SKY NEWS HD":"Sky News", 
                       "SKY NICK (UK)":"Nickelodeon UK",
                       "SKY NICK TOONS (UK)":"Nick Toons UK",
                       "SLICE HD":"SLICE",    
                       "SPIKE HD":"Spike", 
                       "STARZ BLACK HD":"Starz In Black",
                       "STARZ COMEDY HD - NEW":"Starz Comedy", 
                       "STARZ EDGE HD":"Starz Edge", 
                       "STARZ HD":"Starz",
                       "STARZ KIDZ HD - NEW":"Starz Kids",
                       "Sky 3E":"3E", 
                       "Sky Alibi":"Alibi", 
                       "Sky Animal Planet":"Animal Planet UK",
                       "Sky Channel 4":"Channel 4", 
                       "Sky Channel 5":"Channel 5", 
                       "Sky Comedy Network":"Comedy Central UK",
                       "Sky Crime and Investigation":"Crime and Investigation",
                       "Sky Dave":"Dave",    
                       "Sky Discovery":"Discovery UK", 
                       "Sky Discovery History":"Discovery History",
                       "Sky Discovery Science":"Discovery Science UK", 
                       "Sky Discovery Shed":"Discovery Shed", 
                       "Sky Discovery Turbo":"Discovery Turbo",
                       "Sky Discovery investigation":"Discovery Investigation UK",
                       "Sky Eden":"Eden", 
                       "Sky Film 4":"Film4", 
                       "Sky Food":"Food UK",
                       "Sky Gold":"Gold", 
                       "Sky Home":"Home", 
                       "Sky Movie Romance":"Sky Movies Drama",
                       "Sky Movies Atlantic":"Sky Atlantic",    
                       "Sky Movies Sci-Fi":"Sky Movies Scifi", 
                       "Sky Natgeo":"National Geographic UK",
                       "SKY News":"Sky News",
                       "Sky One":"Sky1", 
                       "Sky Quest":"Quest", 
                       "Sky RTE 1":"RTE1",
                       "Sky RTE 2":"RTE2",
                       "Sky Watch":"Watch",  
                       "Sky Yesterday":"Yesterday", 
                       "Sky itv1":"ITV1",
                       "Sky itv2":"ITV2", 
                       "Sky itv3":"ITV3",
                       "Sky itv4":"ITV4",
                       "SyFy HD":"Syfy",
                       "TBS HD":"TBS",    
                       "TCM EAST HD":"TCM", 
                       "TCM HD":"TCM",
                       "THRILLER MAX HD - NEW":"ThrillerMax", 
                       "TLC HD":"TLC", 
                       "TNT HD":"TNT",
                       "TRAVEL HD":"Travel",
                       "TREEHOUSE HD (NA)":"TREEHOUSE", 
                       "TRU TV HD":"truTV", 
                       "TV LAND HD":"TV Land",
                       "TVO HD (NA)":"TVO", 
                       "USA NETWORK HD":"USA Network", 
                       "VELOCITY HD":"VELOCITY",
                       "VEVO 1 HD":"VEVO1",
                       "VEVO 2 HD":"VEVO2",    
                       "VH1 HD":"VH1",    
                       "VICELAND HD":"Viceland", 
                       "W MOVIES HD":"W MOVIES",
                       "W NETWORK HD":"W NETWORK", 
                       "WE TV HD":"WE TV", 
                       "WEATHER CANADA HD":"Weather Canada",
                       "WEATHER USA HD":"Weather USA",
                       "WIN TV HD":"WIN TV",
                       "YTV HD (NA)":"YTV",
                       "Astro Supersports 1 HD":"Astro SuperSport 1", 
                       "Astro Supersports 2 HD":"Astro SuperSport 2", 
                       "Astro Supersports 3 HD":"Astro SuperSport 3",                        
                       "Astro Supersports 4 HD":"Astro SuperSport 4",                         
                       #"Astro Supersports 1 HD":"Astro Supersports 1", 
                       #"Astro Supersports 2 HD":"Astro Supersports 2", 
                       #"Astro Supersports 3 HD":"Astro Supersports 3",                        
                       #"Astro Supersports 4 HD":"Astro Supersports 4",                    
                       "BEIN HD":"BEINS1", 
                       "CBS SPORTS HD":"CBS Sports",
                       "ESPN HD":"ESPN",
                       "ESPN 2 HD":"ESPN2",    
                       "FOX SPORTS 1 HD":"Fox Sports 1 HD", 
                       "FOX SPORTS 2 HD":"Fox Sports 2 HD",
                       "GOLF HD":"Golf Channel", 
                       "MLB HD 01":"MLB1", 
                       "MLB HD 02":"MLB2", 
                       "MLB HD 03":"MLB3",                       
                       "MLB HD 04":"MLB4",                        
                       "MLB HD 05":"MLB5", 
                       "MLB HD 06":"MLB6",                        
                       "MLB HD 07":"MLB7",                        
                       "MLB HD 08":"MLB8",                       
                       "MLB HD 09":"MLB9",                        
                       "MLB HD 10":"MLB10",                       
                       "MLB HD 11":"MLB11",                       
                       "MLB HD 12":"MLB12",                      
                       "MLB NETWORK":"MLB Network",
                       "NBA HD":"NBA TV",
                       "NBC SPORTS":"NBCSN", 
                       "NFL NOW HD":"NFL NOW",
                       "NHL NETWORK HD":"NHL Network", 
                       "NHL ON VERSUS HD":"VERSUS", 
                       "SKY BOX NATION":"BoxNation",
                       "SKY BT 1":"BT Sport 1",
                       "SKY BT 2":"BT Sport 2",    
                       "SKY BT 1 HD":"BT Sport 1 HD",
                       "SKY BT 2 HD":"BT Sport 2 HD",
                       "Sky Sports News HD":"Sky Sports News", 
                       "SKY SPORTS 1":"Sky Sports 1 HD", 
                       "SKY SPORTS 2":"Sky Sports 2 HD", 
                       "SKY SPORTS 3":"Sky Sports 3 HD",                        
                       "SKY SPORTS 4":"Sky Sports 4 HD",                       
                       "SKY SPORTS 5":"Sky Sports 5 HD",                       
                       "SONY ESPN HD - LIVE EVENTS":"PPV",
                       #"SPORT TIME TV 1HD":"SPORT TIME TV 1HD", 
                       "SPORTSNET 360":"Sportsnet 360", 
                       "SPORTSNET ONE HD":"Sportsnet One",
                       "SPORTSNET ONT":"Sportsnet Ontario",
                       "SPORTSNET WORLD HD":"Sportsnet World", 
                       "Sky Sports News HD":"Sky Sports News HD",
                       "Sony Six HD":"Sony Six", 
                       "TEN CRICKET HD":"TEN Cricket", 
                       "TENNIS HD":"Tennis Channel",
                       "TSN 1 HD":"TSN1",
                       "TSN 2 HD":"TSN2",
                       "TSN 3 HD":"TSN3",                       
                       "TSN 4 HD":"TSN4",                       
                       "TSN 5 HD":"TSN5",                      
                       "WILLOW CRICKET HD":"WILLOW CRICKET",    
                       "WWE HD":"WWE Network", 
                       "W NETWORK":"W Network", 
                       "YANKEES HD - NEW":"YANKEES",
                       "HUSTLER HD":"HUSTLER", 
                       "PLAYBOY TV HD - NEW":"PLAYBOY", 
                       "VIVID TV - NEW":"VIVID"
                      }                      
    #channelname_map = {} 
    namemap_file = ''
    if namemap_file:
      with open(namemap_file) as f:
        for line in f:
          sp_line = line.rstrip(os.linesep).split("\t")
          channelname_map[sp_line[0]] = sp_line[1]
          
    #fuck
    inv_map = {v: k for k, v in my_map.items()}
    
    Channel = namedtuple('Channel', ['tvg_id', 'tvg_name', 'tvg_logo', 'group_title', 'channel_url'])
    channels = []
    online_groups = set()

    #
    # Grab Channels
    for ts_id, info in j["available_channels"].iteritems():
      #channel_url = "http://2.welcm.tv:8000/live/{}/{}/{}.m3u8".format(username, password, ts_id)
      #channel_url = urlpath+":8000/live/{}/{}/{}.m3u8".format(username, password, ts_id)
      channel_url = urlpath+"/live/{}/{}/{}.m3u8".format(username, password, ts_id)
      tvg_id = ""
      tvg_name = info['name']
      if info['epg_channel_id'] and info['epg_channel_id'].endswith(".com"):
        tvg_id = info['epg_channel_id']
      if tvg_name in my_map:
        tvg_id = my_map[tvg_name]
      tvg_logo = ""
      #if info['stream_icon']:
      #  tvg_logo = info['stream_icon']
      group_title = info['category_name']
      online_groups.add(group_title)
      if tvg_name in channelname_map:
        tvg_name = channelname_map[tvg_name]
      channels.append(Channel(tvg_id, tvg_name, tvg_logo, group_title, channel_url))
    #
    # Grab Groups
    wanted_groups = sorted(online_groups)
    if groups:
      wanted_groups = groups.split(',')
      
    #fuck
    group_idx = {group:idx for idx,group in enumerate(wanted_groups)}
    
    # Has error if channel listings is different 
    #sys.stderr.write("Channel groups: {}\n".format(",".join(wanted_groups)))
    wanted_channels = [c for c in channels if c.group_title in wanted_groups]
    wanted_channels.sort(key=lambda c: "{}-{}".format(group_idx[c.group_title], c.tvg_name))
    #
    # Sort Channels
    channel_fn = ''
    if channel_fn:
      #with open(channel_fn, 'w') as channel_f:
      with open(channel_fn, write_style) as channel_f:
        for c in wanted_channels:
          if c.tvg_id.endswith(".com"):
            if c.tvg_name in inv_map:
              channel_f.write("{}\n".format(inv_map[c.tvg_name]))
            else:
              channel_f.write("{}\n".format(c.tvg_id))
    #
    # Create m3u
    notify('m3u Subscription',addon_name + '.m3u',os.path.join('special://home/addons', addon_name, 'icon.png'))##NOTIFY##
    output_fn = addon_name + '.m3u'
    write_style = 'w'
    with codecs.open(m3upath + '/' + output_fn, write_style, 'utf-8') as f:     
      f.write('#EXTM3U\n#http://'+Name+'\n')
      for c in wanted_channels:
        #f.write('#EXTINF:-1 tvg-id="{0}" tvg-name="{1}" tvg-logo="{1}.png" group-title="{3}",{1}\n{4}\n'.format(c.tvg_id, c.tvg_name, c.tvg_logo, c.group_title, c.channel_url))
        #f.write('#EXTINF:-1 tvg-logo="{1}.png",{1}\n{4}\n'.format(c.tvg_id, c.tvg_name, c.tvg_logo, c.group_title, c.channel_url))
        f.write('#EXTINF:-1 tvg-id="{1}" tvg-name="{1}" tvg-logo="{1}.png" group-title="{3}",{1}\n{4}\n'.format(c.tvg_id, c.tvg_name, c.tvg_logo, c.group_title, c.channel_url))
    #
    Clean_Names(m3upath + '/' + output_fn, basePath+'/_iptvsubs.m3u') 
    #AppendText(m3upath + '/' + output_fn, dbPath + '/playlist.m3u')
    
      
    #
    # Create ini  
    #ini_file = addon_name + '.m3u.ini'
    ini_file = addon_name + '.ini'
    
    notify('ini Subscription',ini_file,os.path.join('special://home/addons', addon_name, 'icon.png'))##NOTIFY##
    write_style = 'w'
    with open(inipath + '/' + ini_file, write_style) as f:
        f.write('['+addon_name+'] \n;'+Name+'\n')
        for c in wanted_channels:
            f.write('{1}={4}\n'.format(c.tvg_id, c.tvg_name, c.tvg_logo, c.group_title, c.channel_url))
    #
     
    # This will overwrite the json subscription method.  Its for the naming and ordering.              
    M3U8_TS_Replace(inipath + '/' + ini_file, tmp_File)
    #M3U8_TS_New( + '/' + , basePath+'/' + addon_name + '.ini') 
    #AppendText(inipath + '/' + ini_file, xbmc.translatePath(os.path.join(basePath, 'addons.ini')))



###################################################################################################
################################################################################################### CLEAN
###################################################################################################



#################################################
# Clean m3u and ini channel names #
#################################################
def Clean_Names(Clean_Name,tmpFile):
    #tmpFile = os.path.join(basePath, '_backup.ini')
    if os.path.exists(tmpFile):
        os.remove(tmpFile)
    os.rename(Clean_Name, tmpFile)
    s=open(tmpFile).read()
    # Clean these names in addons.ini #
    s=s.replace('ABC HD.png','ABC_HD.png')
    s=s.replace('ABC West.png','ABC_West.png')
    s=s.replace('ABC News.png','ABC_News.png')
    s=s.replace('AMC HD.png','AMC_HD.png')
    s=s.replace('Animal Planet.png','Animal_Planet.png')
    s=s.replace('BBC America.png','BBC_America.png')
    s=s.replace('BBC News.png','BBC_News.png')
    s=s.replace('CBC News.png','CBC_News.png')
    s=s.replace('CBC Vancouver.png','CBC_Vancouver.png')
    s=s.replace('CBS HD.png','CBS_HD.png')
    s=s.replace('CBS West.png','CBS_West.png')
    s=s.replace('CBS News.png','CBS_News.png')
    s=s.replace('CCTV News.png','CCTV_News.png')     
    s=s.replace('CEEN TV.png','CEEN_TV.png')      
    s=s.replace('City TV Vancouver.png','City_TV_Vancouver.png')
    s=s.replace('CTV Regina.png','CTV_Regina.png')
    s=s.replace('CTV Toronto.png','CTV_Toronto.png')
    s=s.replace('CTV Vancouver.png','CTV_Vancouver.png')
    s=s.replace('CTV North.png','CTV_North.png')
    s=s.replace('Cartoon Network.png','Cartoon_Network.png')
    s=s.replace('City TV Toronto.png','City_TV_Toronto.png')
    s=s.replace('Comedy Central.png','Comedy_Central.png')
    s=s.replace('Comedy Central UK.png','Comedy_Central_UK.png')
    s=s.replace('Crime and Investigation.png','Crime_and_Investigation.png')
    s=s.replace('Discovery Science.png','Discovery_Science.png')
    s=s.replace('Discovery Science UK.png','Discovery_Science_UK.png')
    s=s.replace('Discovery History.png','Discovery_History.png')
    s=s.replace('Discovery Investigation.png','Discovery_Investigation.png')
    s=s.replace('Discovery Investigation UK.png','Discovery_Investigation_UK.png')
    s=s.replace('Discovery Shed.png','Discovery_Shed.png')
    s=s.replace('Discovery Turbo.png','Discovery_Turbo.png')
    s=s.replace('Discovery UK.png','Discovery_UK.png')
    s=s.replace('Disney XD.png','Disney_XD.png')
    s=s.replace('Disney XD UK.png','Disney_XD_UK.png')
    s=s.replace('Disney Jr UK.png','Disney_Jr_UK.png')
    s=s.replace('Encore Western.png','Encore_Western.png')
    s=s.replace('FOX HD.png','FOX_HD.png')
    s=s.replace('FEVA TV.png','FEVA_TV.png')
    s=s.replace('FOX West.png','FOX_West.png')
    s=s.replace('FOX News.png','FOX_News.png')
    s=s.replace('Food Network.png','Food_Network.png')
    s=s.replace('Food UK.png','Food_UK.png')
    s=s.replace('Fox News.png','Fox_News.png')
    s=s.replace('Global Vancouver.png','Global_Vancouver.png')
    s=s.replace('Global Toronto.png','Global_Toronto.png')
    s=s.replace('HBO Comedy.png','HBO_Comedy.png')
    s=s.replace('HBO HD.png','HBO_HD.png')
    s=s.replace('HBO Signature.png','HBO_Signature.png')
    s=s.replace('Movie Time.png','Movie_Time.png')
    s=s.replace('NBC HD.png','NBC_HD.png')
    s=s.replace('NBC West.png','NBC_West.png')
    s=s.replace('Nat Geo Wild.png','Nat_Geo_Wild.png')
    s=s.replace('National Geographic.png','National_Geographic.png')
    s=s.replace('Nick Toons UK.png','Nick_Toons_UK.png')       
    s=s.replace('OMNI 1.png','OMNI_1.png')      
    s=s.replace('OMNI 2.png','OMNI_1.png')   
    s=s.replace('RT Documentary.png','RT_Documentary.png')     
    s=s.replace('RT News.png','RT_News.png')  
    s=s.replace('Rev USA.png','Rev_USA.png')
    s=s.replace('Sky News.png','Sky_News.png')
    s=s.replace('Starz In Black.png','Starz_In_Black.png')
    s=s.replace('Starz Comedy.png','Starz_Comedy.png')
    s=s.replace('Starz Edge.png','Starz_Edge.png')
    s=s.replace('Starz Kids & Family.png','Starz_Kids_&_Family.png')
    s=s.replace('Showtime HD.png','Showtime_HD.png')
    s=s.replace('Showtime Showcase.png','Showtime_Showcase.png')
    s=s.replace('Animal Planet UK.png','Animal_Planet_UK.png')
    s=s.replace('Channel 4.png','Channel_4.png')
    s=s.replace('Channel 5.png','Channel_5.png')
    s=s.replace('Discovery History UK.png','Discovery_History_UK.png')
    s=s.replace('Discovery Science.png','Discovery_Science.png')
    s=s.replace('Discovery Investigation.png','Discovery_Investigation.png')
    s=s.replace('Sky Atlantic.png','Sky_Atlantic.png')
    s=s.replace('Sky Movies Drama.png','Sky_Movies_Drama.png')
    s=s.replace('Sky Movies Action.png','Sky_Movies_Action.png')
    s=s.replace('Sky Movies Comedy.png','Sky_Movies_Comedy.png')
    s=s.replace('Sky Movies Disney.png','Sky_Movies_Disney.png')
    s=s.replace('Sky Movies Family.png','Sky_Movies_Family.png')
    s=s.replace('Sky Movies Premiere.png','Sky_Movies_Premiere.png')
    s=s.replace('Sky Movies Scifi.png','Sky_Movies_Scifi.png')
    s=s.replace('Sky Movies Select.png','Sky_Movies_Select.png')
    s=s.replace('Sky Movies Showcase.png','Sky_Movies_Showcase.png')
    s=s.replace('Starz Kids.png','Starz_Kids.png')
    s=s.replace('National Geographic UK.png','National_Geographic_UK.png')
    s=s.replace('TV Land.png','TV_Land.png')
    s=s.replace('TV JAMAICA.png','TV_JAMAICA.png')
    s=s.replace('Travel XP.png','Travel_XP.png')
    s=s.replace('USA Network.png','USA_Network.png')
    s=s.replace('W MOVIES.png','W_MOVIES.png')
    s=s.replace('WE TV.png','WE_TV.png')
    s=s.replace('WE NETWORK.png','WE_NETWORK.png')
    s=s.replace('Weather Canada.png','Weather_Canada.png')
    s=s.replace('Weather USA.png','Weather_USA.png')
    s=s.replace('WIN TV.png','WIN_TV.png')
    s=s.replace('ASTRO CRICKET HD.png','ASTRO_CRICKET_HD.png')
    s=s.replace('Arena Sports 1 HD.png','Arena_Sports_1_HD.png')     
    s=s.replace('Arena Sports 2 HD.png','Arena_Sports_2_HD.png')      
    s=s.replace('Arena Sports 3 HD.png','Arena_Sports_3_HD.png') 
    s=s.replace('Arena Sports 4 HD.png','Arena_Sports_4_HD.png')    
    s=s.replace('Astro SuperSport 1.png','Astro_SuperSport_1.png')
    s=s.replace('Astro SuperSport 2.png','Astro_SuperSport_2.png')
    s=s.replace('Astro SuperSport 3.png','Astro_SuperSport_3.png')
    s=s.replace('Astro SuperSport 4.png','Astro_SuperSport_4.png')
    s=s.replace('Fox Sports 1 HD.png','Fox_Sports_1_HD.png')
    s=s.replace('Fox Sports 2 HD.png','Fox_Sports_2_HD.png')
    s=s.replace('Golf Channel.png','Golf_Channel.png')
    s=s.replace('MLB Network.png','MLB_Network.png')
    s=s.replace('NBA TV.png','NBA_TV.png')
    s=s.replace('NFL Network.png','NFL_Network.png')
    s=s.replace('NHL Network.png','NHL_Network.png')
    s=s.replace('BT Sport 1.png','BT_Sport_1.png')
    s=s.replace('BT Sport 2.png','BT_Sport_2.png')
    s=s.replace('BT Sport 1 HD.png','BT_Sport_1_HD.png')
    s=s.replace('BT Sport 2 HD.png','BT_Sport_2_HD.png')
    s=s.replace('BT SPORTS ESPN.png','BT_SPORTS_ESPN.png')
    s=s.replace('BT SPORTS EUROPE.png','BT_SPORTS_EUROPE.png')
    s=s.replace('CBS Sports.png','CBS_Sports.png')
    s=s.replace('CTH 1 HD.png','CTH_1_HD.png') 
    s=s.replace('CTH 2 HD.png','CTH_2_HD.png')  
    s=s.replace('CTH 3 HD.png','CTH_3_HD.png')  
    s=s.replace('CTH 4 HD.png','CTH_4_HD.png') 
    s=s.replace('CTH 5 HD.png','CTH_5_HD.png')      
    s=s.replace('CTH XD HD.png','CTH_XD_HD.png')
    s=s.replace('FOX SPORTS 1 ASIA.png','FOX_SPORTS_1_ASIA.png')   
    s=s.replace('FOX SPORTS 2 ASIA.png','FOX_SPORTS_2_ASIA.png')
    s=s.replace('FOX SPORTS 3 ASIA.png','FOX_SPORTS_3_ASIA.png')
    s=s.replace('MOTO GP.png','MOTO_GP.png') 
    s=s.replace('NFL NOW.png','NFL_NOW.png') 
    s=s.replace('PREMIER SPORTS.png','PREMIER_SPORTS.png')                     
    s=s.replace('Setanta Asia HD.png','Setanta_Asia_HD.png')
    s=s.replace('Sky Sports News.png','Sky_Sports_News.png')
    s=s.replace('Sky Sports 1 HD.png','Sky_Sports_1_HD.png')
    s=s.replace('Sky Sports 2 HD.png','Sky_Sports_2_HD.png')
    s=s.replace('Sky Sports 2 HD.png','Sky_Sports_2_HD.png')
    s=s.replace('Sky Sports 3 HD.png','Sky_Sports_3_HD.png')
    s=s.replace('Sky Sports 4 HD.png','Sky_Sports_4_HD.png')
    s=s.replace('Sky Sports 5 HD.png','Sky_Sports_5_HD.png')
    s=s.replace('Sky Sports F1.png','Sky_Sports_F1.png')
    s=s.replace('Sky Sports News.png','Sky_Sports_News.png')
    s=s.replace('Sony Six.png','Sony_Six.png')
    s=s.replace('Sportsnet 360.png','Sportsnet_360.png')
    s=s.replace('Sportsnet One.png','Sportsnet_One.png')
    s=s.replace('Sportsnet Ontario.png','Sportsnet_Ontario.png')
    s=s.replace('Sportsnet World.png','Sportsnet_World.png')
    s=s.replace('Tennis Channel.png','Tennis_Channel.png')
    s=s.replace('TEN Cricket.png','TEN_Cricket.png')
    s=s.replace('WWE Network.png','WWE_Network.png')
    s=s.replace('WILLOW CRICKET.png','WILLOW_CRICKET.png')
    #
    #if args.ini_file:
    #    s=s.replace('m3u8','ts')
    f=open(Clean_Name,'a')
    f.write(s)
    f.close()
    os.remove(tmpFile)
    return


# Run #
if __name__ == '__main__':
    if add_IPTVsubs():
        add_IPTVsubs()
        print 'Subscriptions1'
    else:
        #StartCreate()
        print 'Subscriptions2'
